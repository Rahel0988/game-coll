package rahel.weldemariyam.mygame;

import androidx.lifecycle.ViewModel;

public class MyViewModel extends ViewModel {
}
