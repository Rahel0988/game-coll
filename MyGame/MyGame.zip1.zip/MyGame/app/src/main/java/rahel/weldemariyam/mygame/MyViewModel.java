package rahel.weldemariyam.mygame;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class MyViewModel extends ViewModel {

    public static final int TIMER_GAME_ID = 1;
    public static final int RACE_GAME_ID = 2;
    public static final int CAT_HAND_GAME_ID = 3;

    private int selectedGameID;

    public int getSelectedGameID() {
        return selectedGameID;
    }

    public void setSelectedGameID(int selectedGameID) {
        this.selectedGameID = selectedGameID;
    }

}

